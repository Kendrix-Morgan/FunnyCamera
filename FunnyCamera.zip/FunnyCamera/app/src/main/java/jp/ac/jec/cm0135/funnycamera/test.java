package jp.ac.jec.cm0135.funnycamera;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class test extends AppCompatActivity {
    private static final String TAG = test.class.getSimpleName();
    public static final String[] REQUIRED_PERMISSIONS_API29 = new String[]{android.Manifest.permission.CAMERA};

    private final ActivityResultLauncher<String[]> requestPermissions =
            registerForActivityResult(
                    new ActivityResultContracts.RequestMultiplePermissions(),
                    (Map<String, Boolean> grantStates) -> {
                        var isPermissionAllGranted = grantStates.entrySet()
                                .stream()
                                .allMatch(Map.Entry::getValue);
                        Log.d(TAG, "isPermissionAllGranted: " + isPermissionAllGranted);
                        if (!isPermissionAllGranted) {
                            Log.w(TAG, "全ての権限を許可しないとアプリが正常に動作しません");
                        }
                    });

    @Nullable
    private ImageCapture imageCapture;

    private int[] characterImages = {
            R.drawable.character,
            R.drawable.character1,
            R.drawable.character2,
            R.drawable.character3,
            R.drawable.character4
    };
    private int currentCharacterIndex = 0;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_test);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        requestPermissions.launch(REQUIRED_PERMISSIONS_API29);
        startCamera();

        findViewById(R.id.btn_take_picture).setOnClickListener(v -> takePicture());

        ImageView overlayImage = findViewById(R.id.overlayImage);
        ImageButton btnAddCharacter = findViewById(R.id.btn_add_character);

        String mode = getIntent().getStringExtra("mode");

        if ("character".equals(mode)) {
            overlayImage.setImageResource(characterImages[currentCharacterIndex]);
            overlayImage.setVisibility(View.VISIBLE);
            btnAddCharacter.setVisibility(View.VISIBLE); //  show the add button
        } else if ("speech".equals(mode)) {
            overlayImage.setImageResource(R.drawable.serifu);
            overlayImage.setVisibility(View.VISIBLE);
            btnAddCharacter.setVisibility(View.GONE); // hide the add button
        } else {
            overlayImage.setVisibility(View.GONE);
            btnAddCharacter.setVisibility(View.GONE); // hide the add button
        }
        overlayImage.setOnTouchListener(new View.OnTouchListener() {
            float dX, dY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        v.setX(event.getRawX() + dX);
                        v.setY(event.getRawY() + dY);
                        break;
                }
                return true;
            }
        });


        btnAddCharacter.setOnClickListener(v -> {
            currentCharacterIndex = (currentCharacterIndex + 1) % characterImages.length;
            overlayImage.setImageResource(characterImages[currentCharacterIndex]);
            overlayImage.setVisibility(View.VISIBLE);
        });
    }

    private void startCamera() {
        var cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                var cameraProvider = cameraProviderFuture.get();
                final PreviewView viewFinder = findViewById(R.id.view_finder);
                var preview = new Preview.Builder().build();
                preview.setSurfaceProvider(viewFinder.getSurfaceProvider());
                imageCapture = new ImageCapture.Builder().build();
                var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA;
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture);
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "error: ", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takePicture() {
        if (imageCapture == null) return;

        var dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS");
        var fileName = LocalDateTime.now().format(dateTimeFormatter);
        var contentValues = new ContentValues();
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        contentValues.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FunnyCamera");

        var imageCollection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);

        var outputOptions = new ImageCapture.OutputFileOptions.Builder(
                getContentResolver(), imageCollection, contentValues
        ).build();

        imageCapture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults output) {
                        Log.d(TAG, "savedUri = " + output.getSavedUri());
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        Log.e(TAG, "error ", exception);
                    }
                }
        );
    }
}